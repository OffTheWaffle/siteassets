<?php
$consumer_key = '07db0c758eb1b1227ba29ba040693752';
$consumer_secret = null;
$token = '2e6a8e065488ac69884746c09e2d30b94488d6569ed11aedde97ac7c908b5e6b';
$board_ids = array('source'=>'fJvWQ7Js','shop1'=>'Ja5aq36S','shop2'=>'EMMAUu1W','shop3'=>'sPy4zxVO');
$key_path = '?key=07db0c758eb1b1227ba29ba040693752&token=2e6a8e065488ac69884746c09e2d30b94488d6569ed11aedde97ac7c908b5e6b&';
?>